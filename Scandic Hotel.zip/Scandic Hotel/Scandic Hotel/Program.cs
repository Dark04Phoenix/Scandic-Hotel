﻿using System;
using System.Data.SqlClient;

class Program
{
    static void Main(string[] args)
    {
        //Opretter et objekt af DBClient og kalder start metoden
        DBClient dbClient = new DBClient();
        dbClient.Start();

        Console.WriteLine("Tryk på Enter for at afslutte...");
        Console.ReadLine();
    }
}

public class DBClient
{
    private string connectionString = "Data Source=GALAXY;Initial Catalog=Scandic Hotel;Integrated Security=True;";

    public void Start()
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            PrintScandicTable(connection);
            PrintVærelseTable(connection);
            PrintHotelKædeTable(connection);
            PrintKundeTable(connection);
            PrintReservationTable(connection);
            PrintFacilitetTable(connection);
            PrintLandTable(connection);

            // Loop, så programmet ikke afsluttes
            bool exitProgram = false;
            while (!exitProgram)
            {
                Console.WriteLine("Vil du oprette en ny facilitet, læse faciliteter, opdatere en facilitet eller slette en facilitet? (opret/læs/opdater/slet/nej)");
                string userInput = Console.ReadLine().ToLower();

                Console.WriteLine($"Brugerindtastning: {userInput}");

                switch (userInput)
                {
                    case "opret":
                        Console.WriteLine("Valgte at oprette en facilitet.");
                        CreateFacilitet(connection);
                        break;
                    case "læs":
                        Console.WriteLine("Valgte at læse faciliteter.");
                        ReadFacilitetTable(connection);
                        break;
                    case "opdater":
                        Console.WriteLine("Valgte at opdatere en facilitet.");
                        UpdateFacilitet(connection);
                        break;
                    case "slet":
                        Console.WriteLine("Valgte at slette en facilitet.");
                        DeleteFacilitet(connection);
                        break;
                    default:
                        Console.WriteLine($"Ugyldigt input: {userInput}. Prøv igen.");
                        break;
                }
            }
        } // Forbindelsen lukker automatisk, når using-blokken afsluttes
    }

    private void PrintScandicTable(SqlConnection connection)
    {
        string query = "SELECT * FROM Scandic";
        ExecuteAndPrintTable(connection, query);
    }

    private void PrintVærelseTable(SqlConnection connection)
    {
        string query = "SELECT * FROM Værelse";
        ExecuteAndPrintTable(connection, query);
    }

    private void PrintHotelKædeTable(SqlConnection connection)
    {
        string query = "SELECT * FROM HotelKæde";
        ExecuteAndPrintTable(connection, query);
    }

    private void PrintKundeTable(SqlConnection connection)
    {
        string query = "SELECT * FROM Kunde";
        ExecuteAndPrintTable(connection, query);
    }

    private void PrintReservationTable(SqlConnection connection)
    {
        string query = "SELECT * FROM Reservation";
        ExecuteAndPrintTable(connection, query);
    }

    private void PrintFacilitetTable(SqlConnection connection)
    {
        string query = "SELECT * FROM Facilitet";
        ExecuteAndPrintTable(connection, query);
    }

    private void PrintLandTable(SqlConnection connection)
    {
        string query = "SELECT * FROM Land";
        ExecuteAndPrintTable(connection, query);
    }

    private void CreateFacilitet(SqlConnection connection)
    {
        Console.WriteLine("Indtast facilitetsnavn:");
        string facilitetsnavn = Console.ReadLine();

        Console.WriteLine("Indtast HotelID:");
        int hotelID;
        while (!int.TryParse(Console.ReadLine(), out hotelID))
        {
            Console.WriteLine("Ugyldigt input. Indtast et heltal for HotelID:");
        }

        string insertFacilitetQuery = $"INSERT INTO Facilitet (Facilitetsnavn, HotelID) VALUES ('{facilitetsnavn}', {hotelID})";

        using (SqlCommand cmd = new SqlCommand(insertFacilitetQuery, connection))
        {
            cmd.ExecuteNonQuery();
        }

        Console.WriteLine("Facilitet oprettet!");
    }

    private void ReadFacilitetTable(SqlConnection connection)
    {
        string query = "SELECT * FROM Facilitet";
        ExecuteAndPrintTable(connection, query);
    }

    private void UpdateFacilitet(SqlConnection connection)
    {
        Console.WriteLine("Indtast FacilitetID for den facilitet, du vil opdatere:");
        int facilitetID;
        while (!int.TryParse(Console.ReadLine(), out facilitetID))
        {
            Console.WriteLine("Ugyldigt input. Indtast et heltal for FacilitetID:");
        }

        Console.WriteLine("Indtast nyt facilitetsnavn:");
        string nytFacilitetsnavn = Console.ReadLine();

        Console.WriteLine("Indtast nyt HotelID:");
        int nytHotelID;
        while (!int.TryParse(Console.ReadLine(), out nytHotelID))
        {
            Console.WriteLine("Ugyldigt input. Indtast et heltal for nyt HotelID:");
        }

        string updateFacilitetQuery = $"UPDATE Facilitet SET Facilitetsnavn = '{nytFacilitetsnavn}', HotelID = {nytHotelID} WHERE FacilitetID = {facilitetID}";

        using (SqlCommand cmd = new SqlCommand(updateFacilitetQuery, connection))
        {
            int rowsAffected = cmd.ExecuteNonQuery();
            if (rowsAffected > 0)
            {
                Console.WriteLine("Facilitet opdateret!");
            }
            else
            {
                Console.WriteLine("Ingen faciliteter blev opdateret. Tjek FacilitetID og prøv igen.");
            }
        }
    }

    private void DeleteFacilitet(SqlConnection connection)
    {
        Console.WriteLine("Indtast FacilitetID for den facilitet, du vil slette:");
        int facilitetID;
        while (!int.TryParse(Console.ReadLine(), out facilitetID))
        {
            Console.WriteLine("Ugyldigt input. Indtast et heltal for FacilitetID:");
        }

        string deleteFacilitetQuery = $"DELETE FROM Facilitet WHERE FacilitetID = {facilitetID}";

        using (SqlCommand cmd = new SqlCommand(deleteFacilitetQuery, connection))
        {
            int rowsAffected = cmd.ExecuteNonQuery();
            if (rowsAffected > 0)
            {
                Console.WriteLine("Facilitet slettet!");
            }
            else
            {
                Console.WriteLine("Ingen faciliteter blev slettet. Tjek FacilitetID og prøv igen.");
            }
        }
    }

    private void ExecuteAndPrintTable(SqlConnection connection, string query)
    {
        using (SqlCommand command = new SqlCommand(query, connection))
        {
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        Console.Write($"{reader.GetName(i)}: {reader[i]} ");
                    }
                    Console.WriteLine();
                }
            }
        }
        Console.WriteLine();
    }
}